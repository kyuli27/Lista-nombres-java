/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio;

/**
 *
 * @author 50497
 */
public class App {

    public static void main(String[] args) {
     
 // Declarar un arreglo de cadenas para almacenar los nombres
        String[] nombres = new String[10];

        
        nombres[0] = "CARLOS";
        nombres[1] = "JHONY";
        nombres[2] = "ANA";
        nombres[3] = "GENESIS";
        nombres[4] = "KEIDY";
        nombres[5] = "MARIO";
        nombres[6] = "ABNE";
        nombres[7] = "JORJE";
        nombres[8] = "MAXIMILIANO";
        nombres[9] = "EMILIO";

    // Imprimir los nombres de tus compañeros
        System.out.println("Nombres de tus compañeros de clase:");
        for (int i = 0; i < nombres.length; i++) {
            System.out.println(nombres[i]);
        }
    }
}
